class LithiumRestClient(object):
    pass
